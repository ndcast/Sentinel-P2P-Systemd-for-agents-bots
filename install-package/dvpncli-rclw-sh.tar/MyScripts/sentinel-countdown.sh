#!/bin/bash
ADDRESS=$(cat sentinel-dvpncli/.address 2>/dev/null | cut -d '"' -f2 |xargs)

if [ -z "$ADDRESS" ]; then
  echo "❌ No address in instance (sentinel-dvpncli/.address is empty or missing)"
  exit 1
fi

RPC="https://sentinel-rpc.polkachu.com:443,https://sentinel-rpc.publicnode.com:443"

echo "=== Sentinel Stale Sessions & Balance ==="

bash sentinel-balance.sh | grep DVPN
echo "→ Full balance & history: https://p2pscan.com/address/$ADDRESS"

echo ""


echo -e "\n=== Time until refunds ===\n"

sentinel-dvpncli query sessions \
  --account-addr "$ADDRESS" \
  --rpc.addrs "$RPC" 2>/dev/null | \
awk '
  /id:/ {id=$NF}
  /inactive_at:/ {
    gsub(/"/,"",$NF);
    timestamp = $NF;
    cmd="date -d \"" timestamp "\" +\"%H:%M:%S\""; cmd | getline nice_time; close(cmd);
    cmd2="date -d \"" timestamp "\" +%s"; cmd2 | getline expire; close(cmd2);
    now = systime();
    left = expire - now;
    if (left > 0) {
      m = int(left/60);
      printf "Session %-12s → expires at %s   (%d min left)\n", id, nice_time, m
    } else {
      printf "Session %-12s → %s   ✅ Expired\n", id, nice_time
    }
  }
'

echo -e "\n=== Summary ==="
echo "• Tokens locked in inactive_pending sessions"
echo "• Deposits return automatically when timers hit 0"
echo "• Refresh p2pscan after sessions disappear from the list"
