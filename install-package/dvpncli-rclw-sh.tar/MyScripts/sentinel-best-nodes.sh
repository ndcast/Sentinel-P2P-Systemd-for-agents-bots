#!/bin/bash
# Sentinel Best Nodes - Plan 42 (provider: sentprov12e03wzmxjerwqt63p252cqs90jwfuwdda7wves)

PROVIDER="sentprov12e03wzmxjerwqt63p252cqs90jwfuwdda7wves"

echo "=== Top NL/DE/FR Nodes for Plan 42 ($PROVIDER) ==="

sentinel-dvpncli query nodes --page.limit 500 2>/dev/null | \
awk -v prov="$PROVIDER" '
/address: sentnode/ { addr=$2 }
/provider_address: / || /prov_address: / {
  if ($2 == prov) prov_match=1; else prov_match=0
}
/country_code: (NL|DE|FR)/ {
  country=$2
  if (addr != "" && prov_match) {
    print "Node: " addr
    print "Country: " country
    print "--------------------------------"
    addr = ""
    prov_match = 0
  }
}
' | head -n 60

echo -e "\nProvider filtered: $PROVIDER (Plan 42)"
echo "Run: sentinel-dvpncli tx session-start <Node Address> --subscription-id 1225296 --tx.from-name mydvpn --keyring.backend test --home /home/openclaw/sentinel-dvpncli"