#!/bin/bash
# Fixed Country Filter - NL/DE/FR Priority

echo "[$(date '+%Y-%m-%d %H:%M:%S')] === Selecting Best NL/DE/FR Node ==="

BEST_NODE=$(sentinel-dvpncli query nodes \
  --status active \
  --rpc.addrs https://rpc.sentinel.co:443 \
  --page.limit 500 2>/dev/null | \
awk '
  /address: sentnode/ { addr=$2 }
  /country_code: (NL|DE|FR)/ { country=$2; good=1 }
  /downlink: / { dl=$2+0 }
  /status: 1/ {
      if (addr && good) {
          print dl "|" addr "|" country
          addr = ""; good=0
      }
  }
' | sort -t'|' -nr | head -1 | cut -d'|' -f2)

if [ -n "$BEST_NODE" ]; then
    # Get country for logging
    COUNTRY=$(sentinel-dvpncli query nodes --status active --rpc.addrs https://rpc.sentinel.co:443 --page.limit 10 2>/dev/null | grep -A 20 "$BEST_NODE" | grep -m1 country_code | awk '{print $2}')
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✅ Best EU node: $BEST_NODE ($COUNTRY)"
    echo "$BEST_NODE" > /home/openclaw/.best-sentinel-node
    exit 0
else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ No NL/DE/FR nodes found"
    echo "sentnode1qr48c94aysw9fzvwramr2tzphczlh5q9ymdmey" > /home/openclaw/.best-sentinel-node
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Using FR fallback"
    exit 1
fi
