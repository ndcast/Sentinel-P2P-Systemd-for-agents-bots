#!/bin/bash
# Auto Sentinel Node Picker - Top 5 Best NL/DE/FR (Lowest Latency)

echo "=== Auto Selecting Top 5 Best Sentinel Nodes (NL/DE/FR) ==="

sentinel-dvpncli query nodes --page.limit 200 2>/dev/null | \
awk '
/address: sentnode/ { addr = $2 }
/country_code: (NL|DE|FR)/ { country = $2 }
/city:/ { city = $2 }
/moniker:/ { moniker = $2 }
/peers:/ { peers = $2 }
/service_type:/ { service = $2 }
/latency:/ {
    latency = $2
    print latency "|" addr "|" country "|" city "|" moniker "|" peers "|" service
}' | \
sort -n | \
head -n 5 | \
awk -F'|' '{
    printf "Rank #%d\n", NR
    printf "Node    : %s\n", $2
    printf "Country : %s\n", $3
    printf "City    : %s\n", $4
    printf "Moniker : %s\n", $5
    printf "Peers   : %s\n", $6
    printf "Type    : %s\n", $7
    printf "--------------------------------------------------\n"
}'
