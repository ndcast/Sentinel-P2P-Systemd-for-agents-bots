#!/bin/bash
ADDRESS=$(cat sentinel-dvpncli/.address 2>/dev/null | cut -d '"' -f2 |xargs)

if [ -z "$ADDRESS" ]; then
  echo "❌ No address in instance (sentinel-dvpncli/.address is empty or missing)"
  exit 1
fi

LCD="https://lcd.sentinel.co"

echo "=== Fetching real balance via LCD API ==="

curl -s -X GET \
  -H "Content-Type: application/json" \
  "${LCD}/cosmos/bank/v1beta1/balances/${ADDRESS}" | \
jq -r '.balances[]? | select(.denom == "udvpn") | "\(.amount) udvpn = \(.amount | tonumber / 1000000) DVPN"' || \
echo "No udvpn balance found or API error"

echo -e "\n→ Explorer: https://p2pscan.com/address/$ADDRESS"
