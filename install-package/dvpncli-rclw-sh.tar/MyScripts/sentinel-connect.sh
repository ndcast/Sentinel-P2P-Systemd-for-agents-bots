#!/bin/bash
# Sentinel dVPN Auto-Connect — Improved Active Session Detection
ADDRESS=$(cat sentinel-dvpncli/.address 2>/dev/null | cut -d '"' -f2 |xargs)

if [ -z "$ADDRESS" ]; then
  echo "❌ No address in instance (sentinel-dvpncli/.address is empty or missing)"
  exit 1
fi

HOME_DIR="/home/openclaw/sentinel-dvpncli"
FAV_FILE="/home/openclaw/fav-providers.lst"
BEST_FILE="/home/openclaw/.best-sentinel-node"
KEYRING_BACKEND="test"
RPC="https://sentinel-rpc.polkachu.com:443,https://sentinel-rpc.publicnode.com:443"
LCD="https://lcd.sentinel.co"

# Parse -f flag
USE_FAV=false
if [[ "$1" == "-f" ]]; then
  USE_FAV=true
fi

echo "[$(date '+%H:%M:%S')] Starting Sentinel dVPN..."

# Node selection
if [ "$USE_FAV" = true ] && [ -f "$FAV_FILE" ]; then
  NODE=$(shuf -n1 "$FAV_FILE" | tr -d '[:space:]')
  echo "[$(date '+%H:%M:%S')] Using favorite node: $NODE"
elif [ -f "$BEST_FILE" ]; then
  NODE=$(cat "$BEST_FILE" | tr -d '[:space:]')
  echo "[$(date '+%H:%M:%S')] Using best node: $NODE"
else
  NODE=$(echo -e "sentnode1ldh7ke5x9896px23muen32twcyaykd8rf5a8hd\nsentnode1wdvmpqnex6svem3nmzk67pjc7chh4f66fmq6w0\nsentnode1yzgr72l6kwagce5uh9dk30xxyvwz4007kt99dk\nsentnode1dkh9wjjk00tee2rtnkxvw5t25s8yy74ehtwf6j" | shuf -n1)
  echo "[$(date '+%H:%M:%S')] Using random node: $NODE"
fi

# Real balance
echo "[$(date '+%H:%M:%S')] Checking real balance..."
BALANCE_UDVPN=$(curl -s "${LCD}/cosmos/bank/v1beta1/balances/${ADDRESS}" | jq -r '.balances[]? | select(.denom == "udvpn") | .amount' || echo "0")
BALANCE_DVPN=$((BALANCE_UDVPN / 1000000))
echo "   Current balance: ${BALANCE_DVPN} DVPN"

# ==================== STRICT ACTIVE SESSION CHECK ====================
echo "[$(date '+%H:%M:%S')] Checking for connectable active session..."
SESSION=$(sentinel-dvpncli query sessions \
  --account-addr "$ADDRESS" \
  --rpc.addrs "$RPC" 2>/dev/null | \
  awk '
    /id: [0-9.]+e\+[0-9]+/ {id=$NF}
    /status: 1/ {if (id) {print id; exit}}
  ' | awk '{split($1,a,"e+"); printf "%.0f\n", a[1]*(10^a[2])}')

if [ -n "$SESSION" ]; then
  echo "[$(date '+%H:%M:%S')] ✅ Found connectable active session ($SESSION). Connecting..."
  exec sentinel-dvpncli connect "$SESSION" --home "$HOME_DIR" --keyring.backend "$KEYRING_BACKEND"
else
  echo "[$(date '+%H:%M:%S')] No connectable active session found."
fi

# ==================== START NEW SESSION ====================
echo "[$(date '+%H:%M:%S')] Starting new session with $NODE..."
TX_OUTPUT=$(sentinel-dvpncli tx session-start "$NODE" \
  --tx.from-name mydvpn \
  --keyring.backend "$KEYRING_BACKEND" \
  --home "$HOME_DIR" \
  --rpc.addrs "$RPC" \
  --tx.gas-prices 0.1udvpn \
  --tx.gas-adjustment 1.8 \
  --max-price "udvpn:1,30000" \
  --gigabytes 10 \
  --hours 0 2>&1)

echo "$TX_OUTPUT" | tail -n 30

NEW_SESSION=$(echo "$TX_OUTPUT" | grep -o 'session_id[^0-9]*[0-9]\+' | grep -o '[0-9]\+' | tail -n1)

if [ -z "$NEW_SESSION" ]; then
  sleep 10
  NEW_SESSION=$(sentinel-dvpncli query sessions \
    --account-addr "$ADDRESS" \
    --rpc.addrs "$RPC" 2>/dev/null | \
    awk '/id: [0-9.]+e\+[0-9]+/ {split($NF,a,"e+"); printf "%.0f\n", a[1]*(10^a[2])}' | head -n1)
fi

if [ -n "$NEW_SESSION" ]; then
  echo "[$(date '+%H:%M:%S')] ✅ New session $NEW_SESSION created. Connecting..."
  exec sentinel-dvpncli connect "$NEW_SESSION" --home "$HOME_DIR" --keyring.backend "$KEYRING_BACKEND"
else
  echo "[$(date '+%H:%M:%S')] ❌ Failed to create new session."
fi
